System.config({
  paths: {
    react: '../../../../build/node_modules/react/umd/react.development.js',
    'react-dom':
      '../../../../build/node_modules/react-dom/umd/react-dom.development.js',
    schedule:
      '../../../../build/node_modules/scheduler/umd/schedule.development',
  },
});
